
import java.io.InputStream;
import java.io.OutputStream;


import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class GET_API {

	private final String USER_AGENT = "Mozilla/5.0";

	public static void main(String[] args) throws Exception {

		System.out.println("Hello world!");
		GET_API http = new GET_API();

		int value = 0;
		int x = 0;
		
		String led2 = "eqpID=LED2&eqpPower=";
		String led1 = "eqpID=LED1&eqpPower=";
		String ac = "eqpID=LED3&eqpPower=";

		String power = "";
		
		int Status_LED02 =0;
		int Status_LED01 =0;
		int Status_AC01 =0;
		
		String urlget_LED02 = "https://xs01a67a2589a.hana.ondemand.com/tmp/ong/pidemo/services/getEquipmentPower.xsjs?eqpID=LED02";
		String urlget_LED01 = "https://xs01a67a2589a.hana.ondemand.com/tmp/ong/pidemo/services/getEquipmentPower.xsjs?eqpID=LED01";
		String urlget_AC01 = "https://xs01a67a2589a.hana.ondemand.com/tmp/ong/pidemo/services/getEquipmentPower.xsjs?eqpID=AC01";

		
			try {
			String command = "plink -load Arduino";

			Runtime r = Runtime.getRuntime ();
			Process p = r.exec (command);
			InputStream std = p.getInputStream ();
			OutputStream out = p.getOutputStream ();
			InputStream err = p.getErrorStream ();
    		
			out.write ("root\n".getBytes ());
			System.out.println(std.read());		
			out.flush ();
			
			out.write ("arduino\n".getBytes ());
			System.out.println(std.read());
			out.flush ();
					
			Thread.sleep (1000);
			
			out.write ("telnet localhost 6571\n".getBytes ());
			System.out.println(std.read());
			out.flush ();
   	
			Thread.sleep (1000);
			
			if (std.available () >= 0) {
				System.out.println ("STD:");
				value = std.read ();
				System.out.print ((char) value);

				 while (std.available () > 0 || x < 100 ) {
			            value = std.read ();
			            System.out.print ((char) value);  
			            						x++;
				 }
			 
				 out.flush ();
				 
				while (1 == 1) {
					
		            
					Status_LED02 = Integer.parseInt(http.sendGet(urlget_LED02));
					Status_LED01 = Integer.parseInt(http.sendGet(urlget_LED01));
					Status_AC01 = Integer.parseInt(http.sendGet(urlget_AC01));
					
				//	System.out.print ("LED02:");System.out.println (Status_LED02);
				//	System.out.print ("LED01:");System.out.println (Status_LED01);
				//	System.out.print ("AC01:");System.out.println (Status_AC01);
					
					
					if(Status_LED02 == 0)
					{
						out.write ("4\n".getBytes ());
						out.flush ();	
					}
					if(Status_LED01 == 0)
					{
						out.write ("5\n".getBytes ());
						out.flush ();
					}
					if(Status_AC01 == 0)
					{
						out.write ("6\n".getBytes ());
						out.flush ();
					}
					if(Status_LED02 == 1)
					{
						out.write ("1\n".getBytes ());
						out.flush ();
					}
					if(Status_LED01 == 1)
					{
						out.write ("2\n".getBytes ());
						out.flush ();
					}
					if(Status_AC01 == 1)
					{
						out.write ("3\n".getBytes ());
						out.flush ();
					}
					
					
				}
			}

			if (err.available () > 0) {
				System.out.println ("ERR:");
				value = err.read ();
				System.out.print ((char) value);

				while (err.available () > 0) {
					value = err.read ();
					System.out.print ((char) value);
				}
			}

			p.destroy ();
		}
		catch (Exception e) {
			e.printStackTrace ();
		}

	
	}
	
	
	// HTTP GET request
	private String sendGet(String url) throws Exception {
		
		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// optional default is GET
		con.setRequestMethod("GET");

		//add request header
		con.setRequestProperty("User-Agent", USER_AGENT);

		int responseCode = con.getResponseCode();
		
		//System.out.println("\nSending 'GET' request to URL : " + url);
		//System.out.println("Response Code : " + responseCode);

		BufferedReader in = new BufferedReader(
		        new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		//return result
		
		return response.toString();

		}
	
		// HTTP POST request
		private void sendPost(String url, String urlParameters) throws Exception {

		//	String url = "https://xs01a67a2589a.hana.ondemand.com/tmp/ong/pidemo/services/updateEquipmentDetails.xsjs";
			URL obj = new URL(url);
			HttpsURLConnection con = (HttpsURLConnection) obj.openConnection();

			//add reuqest header
			con.setRequestMethod("POST");
			con.setRequestProperty("User-Agent", USER_AGENT);
			con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

		//	String urlParameters = "eqpID=LED2&eqpPower="+"90";
		
			// Send post request
			con.setDoOutput(true);
			DataOutputStream wr = new DataOutputStream(con.getOutputStream());
			wr.writeBytes(urlParameters);
			wr.flush();
			wr.close();

			int responseCode = con.getResponseCode();
			//System.out.println("\nSending 'POST' request to URL : " + url);
			//System.out.println("Post parameters : " + urlParameters);
			//System.out.println("Response Code : " + responseCode);

			BufferedReader in = new BufferedReader(
		        new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
		
			//print result
		
			System.out.println(response.toString());

		}


	}
