sap.ui.controller("smart_home.v1", {

/**
* Changed Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf smart_home.v1
*/
	onInit: function() {

     setInterval(function(){
			
			
			 jQuery.ajax({
							     
							         	  
							         	url:"https://xs01a67a2589a.hana.ondemand.com/tmp/ong/pidemo/services/getEquipmentPower.xsjs",
							         // url:"https://webidetesting8453028-i317978trial.dispatcher.hanatrial.ondemand.com/services/getEquipmentPower.xsjs",
							               dataType: "json",
							                data : { 
				           	         
				           	                             eqpID :      "INT"
				                          },
				                            crossDomain : true,
				                            success: function(data, textStatus, jqXHR) { // callback called when data is received
							                   
							             	 
							                        // alert(data);
							                       if(data === 1)
							                       
							                       {
							                           alert("check in");
							                            sap.ui.getCore().byId("screen3").addContent(new sap.ui.core.HTML({content: "<iframe name='myFrame' width='100%' height='100%' src='intruder.jpg'  >" }));
                                                          if(!sap.ui.getCore().byId("screen3").isOpen()){
                                                           	sap.ui.getCore().byId("screen3").open();
		                        	                       	} 
		                        	                       	
		                        	                       
		                        	                        sap.ui.commons.MessageBox.confirm("Do you want to inform police station", fnCallbackConfirm, "ALERT");
                                                             function fnCallbackConfirm(bResult)  
          	                                                   {	
          	                                                        if(bResult==true)
        	 		                                                   { 
        	 		                                                       
        	 		                                                        jQuery.ajax({
	                    	      type: 'POST',
	                    	      url: 'https://mandrillapp.com/api/1.0/messages/send.json',
	                    	      data: {
	                    	        'key': 'Y2wWCR_tJG1JK6Kd-G9YLg',
	                    	        'message': {
	                    	          'from_email': 'smartAnalyzer@sap.com',
	                    	          'to': [
	                    	              {
	                    	                'email': 'shubham.saini@sap.com'
//	                    	                'name': 'GamoMeter',
//	                    	                'type': 'to'
	                    	              },
	                    	              {'email': 'srimukha.karantha.babukodi@sap.com'}
	                    	             // {'email': 'venkata.krishna.adhikamsetty@sap.com'},
	                    	              
	                    	            ],
	                    	          'autotext': 'true',
	                    	          'subject': 'Someone is trying to sneak in at at address - 112, prestige appt',
	                    	          'html': '<HTML> <BODY> Emergency!! <br><br> Someone is trying to sneak in at at address - 112, prestige appt <br><br> Please come soon and help. <br><br> Thanks and Regards <br> Smart analyzer </body> </html>'
	                    	                   
	                    	        }
	                    	      }
	                    	     }).done(function(response) {
	                    	       console.log(response); // if you're into that sorta thing
	                    	     });
        	 		                                                       
        	 		                                                   }
        	 		                                                   
          	                                                       
          	                                                   }
          	                                                   
          	                                                   
          	                                                   
          	                                                   
          	                                                   
          	                                                    jQuery.ajax({
							         
							                                	url:"https://xs01a67a2589a.hana.ondemand.com/tmp/ong/pidemo/services/changeStatus.xsjs",
							          
							                                   dataType: "json",
							                                  data : { 
				           	         
				           	                             eqpID :      "INT",
							                             status  :      "0"
							     
					             
				                                             }
							   
							                                    });
							           
							           
							           
							           
		                        	                       	
							                       }
							               }
				                           
			 });
			
		 }, 1000);
		 
	
	},

	handlePress1:function(oControlEvent,oModel)
     {  
		 sap.ui.getCore().byId("app").to("idv2");

		// myVar = setTimeout(alert("hello"), 9000);
	    // clearTimeout(myVar);
	    
		
     },
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf smart_home.v1
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf smart_home.v1
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf smart_home.v1
*/
//	onExit: function() {
//
//	}

});