sap.ui.controller("smart_home.v2", {

/**
* Changed Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf smart_home.v2
*/
//	onInit: function() {
//		
//
//		
//	},
	
	  linkPressed3:function(oControlEvent,oModel)
       {  
           
           alert("h");
           
      
				   
				   var oSplitterV = new sap.ui.commons.Splitter("splitterV");
					oSplitterV.setSplitterOrientation(sap.ui.commons.Orientation.vertical);
					oSplitterV.setSplitterPosition("40%");
					oSplitterV.setMinSizeFirstPane("30%");
					oSplitterV.setMinSizeSecondPane("30%");
					oSplitterV.setWidth("100%");
					oSplitterV.setHeight("100%");

					
			
					  var oSplitterV2 = new sap.ui.commons.Splitter("splitterV2");
						oSplitterV2.setSplitterOrientation(sap.ui.commons.Orientation.vertical);
						oSplitterV2.setSplitterPosition("100%");
						oSplitterV2.setMinSizeFirstPane("30%");
						oSplitterV2.setMinSizeSecondPane("30%");
						oSplitterV2.setWidth("100%");
						oSplitterV2.setHeight("100%");
						
						oSplitterV.addFirstPaneContent(new sap.ui.commons.Image({src :"led.jpg" }));
						oSplitterV.addSecondPaneContent(oSplitterV2);
						
					var oLayout2 = new sap.ui.layout.form.GridLayout("L20");
					var oForm20 = new sap.ui.layout.form.Form("F20",{
						title: new sap.ui.core.Title({text: "Information", tooltip: "Information"}),
						layout: oLayout2,
						formContainers: [
							new sap.ui.layout.form.FormContainer("C20",{
								//title: "Information",
								formElements: [
								               
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: "Unique ID : "}),
										fields: [new sap.ui.commons.TextView({
											text: "123",
											width: "100%",
											layoutData: new sap.ui.layout.form.GridElementData({hCells: "6"})})						
												
										]
									}),

									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									}),
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									}),
									
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: "Category : "}),
										fields: [new sap.ui.commons.TextView({
											text: "LED",
											width: "35%",
											layoutData: new sap.ui.layout.form.GridElementData({hCells: "6"})})						
												
										]
									}),

									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "}),
									}),
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "}),
									}),
									
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: "Description : "}),
										fields: [new sap.ui.commons.TextView({
											text: "LED01 - philips bulb",
											width: "35%",
											layoutData: new sap.ui.layout.form.GridElementData({hCells: "6"})})						
												
										]
									}),

									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									}),
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									}),
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: "Power : "}),
										fields: [new sap.ui.commons.TextView({
											text: "10 Watt",
											width: "35%",
											layoutData: new sap.ui.layout.form.GridElementData({hCells: "6"})})						
												
										]
									}),

									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									}),
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									}),
									
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: "Last Service Date : "}),
										fields: [new sap.ui.commons.TextView({
											text: "18-5-2015",
											width: "35%",
											layoutData: new sap.ui.layout.form.GridElementData({hCells: "6"})})						
												
										]
									}),

									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									}),
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									}),
									
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: "Next Service Date : "}),
										fields: [new sap.ui.commons.TextView({
											text: "18-5-2017",
											width: "35%",
											layoutData: new sap.ui.layout.form.GridElementData({hCells: "6"})})						
												
										]
									}),

									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									}),
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									}),
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: "Dealer"}),
										fields: [new sap.ui.commons.Link({
											text: "Electrcials Pvt Ltd.",
											width: "35%",
											 press : function() 
											 {  
											   // alert("a");
											    
												openDialog3();
							                       function openDialog3() {
							                    	   var oDialog4 = new sap.ui.commons.Dialog();
							                    	   oDialog4.setTitle("Appliance Details");
							                    	   oDialog4.setShowCloseButton(false);
							                 
							                    	   var oVCard = new sap.suite.ui.commons.BusinessCard("vCard",{
							                    		    firstTitle:  new sap.ui.commons.Label({id:"vcard1-name-label",text:"LEAD01",tooltip:"LED01"}),
							                    		    iconPath: "led.jpg",
							                    		    secondTitle: "Living Area",
							                    		    imageTooltip:"White, Helen",
							                    		    width: "424px"
							                    		});

							                    		var oContentCard = new sap.ui.commons.layout.MatrixLayout({widths:["20px", "100px"]});
							                    		
							                    		var oCell = new sap.ui.commons.layout.MatrixLayoutCell({hAlign:sap.ui.commons.layout.HAlign.Center});
							                    		oCell.addContent(new sap.ui.commons.TextView({text:"Duration:"}));
							                    		oContentCard.createRow(oCell, new sap.ui.commons.TextView({text:"245 Days"}));
							                    		
							                    		oCell = new sap.ui.commons.layout.MatrixLayoutCell({hAlign:sap.ui.commons.layout.HAlign.Center});
							                    		oCell.addContent(new sap.ui.commons.TextView({text:"Purchased on:"}));
							                    		oContentCard.createRow(oCell, new sap.ui.commons.TextView({text:"18-02-2015"}));
							                    		
							                    	
							                    				
							                    		oCell = new sap.ui.commons.layout.MatrixLayoutCell({hAlign:sap.ui.commons.layout.HAlign.Center});
							                    		oCell.addContent(new sap.ui.commons.TextView({text:"Dealer's number:"}));
							                    		oContentCard.createRow(oCell, new sap.ui.commons.TextView({text:"+91 (999) 457-2875"}));
							                    				
							                    		oContentCard.createRow(new sap.ui.commons.TextView({text:"Address:"}), new sap.ui.commons.TextView({text:"13-Local Street, Bangalore"}));
							                    		oVCard.setContent(oContentCard);
							                    	   
							                    	   oDialog4.addContent(sap.ui.getCore().byId("vCard"));
							                    	   oDialog4.addButton(new sap.ui.commons.Button({text: "Close", press:function(){

									            	oDialog4.close();  sap.ui.getCore().byId("vCard").destroy();  }}));
							                    	
							                    	 
							        	            oDialog4.open();
							        	              }
						            	 		},
											    
											    
										      

											layoutData: new sap.ui.layout.form.GridElementData({hCells: "6"})})						
												
										]
									}),

									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									}),
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									}),
									
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: "Health Status : "}),
										fields: [new sap.ui.commons.TextView({
											text: "Good",
											width: "35%",
											layoutData: new sap.ui.layout.form.GridElementData({hCells: "6"})})						
												
										]
									}),

									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									}),
									new sap.ui.layout.form.FormElement({
										label: new sap.ui.commons.Label({text: " "})
									})
									
								]
							})
						]
					});
					
					
               /////////////////////////////////////////////////
					//timeline
					
					var aValues = [{
						dateTime : new Date(),
						userNameClickable : true,
						text : "Dispatching to Delhi. Ok to In Transit.",
						userName : "KAR01",
						title : "made a status change",
						filterValue : "Note",
						icon : "sap-icon://notes"
					}, {
						dateTime : new Date(new Date().getTime() - (1000 * 3600 * 24) * 2),
						userNameClickable : true,
						text : "Dispatching to Karnataka.Ok to In Transit",
						userName : "Del01",
						title : "made a status change",
						filterValue : "Status",
						icon : "sap-icon://begin"
					}, {
						dateTime : new Date(new Date().getTime() - (1000 * 3600 * 24) * 3),
						userNameClickable : true,
						text : "Asset-Laptop received from Sponser-SAP Labs",
						userName : "DEL01",
						title : "addded a note",
						filterValue : "Note",
						icon : "sap-icon://notes"
					}];

					var oModel = new sap.ui.model.json.JSONModel({
						values : aValues
					});
					var tlItem = new sap.suite.ui.commons.TimelineItem({
						dateTime : "{dateTime}",
						userNameClickable : "{userNameClickable}",
						text : "{text}",
						userName : "{userName}",
						title : "{title}",
						filterValue : "{filterValue}",
						icon : "{icon}"
					});
					var oPopover = new sap.m.Popover({
						showHeader : false,
						placement : sap.m.PlacementType.Auto,
						contentHeight : "87px",
						contentWidth : "300px"
					});
					var vCardName = new sap.ui.commons.Label();
					var oVCard = new sap.suite.ui.commons.BusinessCard({
						firstTitle : vCardName,
						secondTitle : "Hope Foundation Location",
						width : "298px"
					});
					var oContent = new sap.ui.commons.layout.MatrixLayout({
						widths : ["30px", "100px"]
					});
					oContent.createRow(new sap.ui.commons.TextView({
						text : "Phone:"
					}), new sap.ui.commons.TextView({
						text : "+91 (999) 457-2875"
					}));
					oContent.createRow(new sap.ui.commons.TextView({
						text : "Email:"
					}), new sap.ui.commons.TextView({
						text : "abc@hope.com"
					}));
					oVCard.setContent(oContent);
					oPopover.addContent(oVCard);
					tlItem.attachUserNameClicked(function(oControlEvent) {
						var oItem = oControlEvent.getSource();
						vCardName.setText(oItem.getUserName());
						oVCard.setIconPath("images/persons/male_MillerM.jpg");
						oPopover.openBy(oItem._userNameLink);
					});
					var timeline = new sap.suite.ui.commons.Timeline();
					timeline.setModel(oModel);
					timeline.bindAggregation("content", {
						path : "/values",
						template : tlItem
					});
					var tlItem1 = new sap.suite.ui.commons.TimelineItem({
						dateTime : new Date(new Date().getTime() - (1000 * 3600 * 12)),
						userNameClickable : true,
						userName : "KAR01",
						title : "made a status change",
						filterValue : "Status",
						icon : "sap-icon://action",
						text : "OK to In Transit "
//						embeddedControl : new sap.m.Link({
//							text : "Link to SAP home page",
//							href : "http://www.sap.com",
//							target : "_blank"
//						})
					});
					tlItem1.attachUserNameClicked(function(oControlEvent) {
						var oItem = oControlEvent.getSource();
						vCardName.setText(oItem.getUserName());
						oVCard.setIconPath("images/persons/female_IngallsB.jpg");
						oPopover.openBy(oItem._userNameLink);
					});
					timeline.addContent(tlItem1);
					var tlItem2 = new sap.suite.ui.commons.TimelineItem({
						dateTime : new Date(new Date().getTime() - (1000 * 3600 * 30)),
						userNameClickable : true,
						userName : "KAR01",
						title : "added a note",
						filterValue : "Note",
						icon : "sap-icon://action",
						embeddedControl : new sap.m.Button({
							text : "Note",
							width : "90px",
							press : function() {
								alert("Received Laptop in good condition");
							}
						})
					});
					tlItem2.attachUserNameClicked(function(oControlEvent) {
						var oItem = oControlEvent.getSource();
						vCardName.setText(oItem.getUserName());
						oVCard.setIconPath("images/persons/male_SmithJo.jpg");
						oPopover.openBy(oItem._userNameLink);
					});
					timeline.addContent(tlItem2);
					timeline.setSortOldestFirst(false);
					timeline.setWidth("30%");
					
				
					
					
					
					
				////////////////////////////////////////////////	
					oSplitterV2.addFirstPaneContent(oForm20);
					//oSplitterV2.addSecondPaneContent(timeline);
					
					
					openDialog1();
                    function openDialog1() {
                 	   var oDialog1 = new sap.ui.commons.Dialog();
                 	   oDialog1.setTitle("Information");
                 	   oDialog1.setShowCloseButton(false);
                 	      
                 	   oDialog1.addContent(sap.ui.getCore().byId("splitterV"));
                 	   oDialog1.addButton(new sap.ui.commons.Button({text: "close", press:function(){
		            	oDialog1.close(); sap.ui.getCore().byId("splitterV").destroy();  }}));
     	
     	            oDialog1.open();
     	              }
					
           
       },
	
	
	
	
	
	   linkPressed2:function(oControlEvent,oModel)
       {  

       
         var path = oControlEvent.getSource().getParent().getBindingContextPath();
       	 var controller = this;
       	 var oTable = sap.ui.getCore().byId("list");
       	 var oModel = oTable.getModel();
         var data = oModel.getProperty(path);
       // alert(data.Name);
         
         if(data.status === "Switch Off")
        	 {
        	     sap.ui.commons.MessageBox.confirm("Do you want to switch it on", fnCallbackConfirm, "ALERT");
                 function fnCallbackConfirm(bResult)  
          	         {
                	// alert("switch off");
                	    if(bResult==true)
        	 		       {  
        	 		           
        	 		           /////////////////////////////////////////
        	 		          // alert(data.Name);
        	 		           jQuery.ajax({
							         	//  url: "https://inblrllssc195.apj.global.corp.sap:4300/GamoMeter_Pkg/GamoMeter_XS/RetrieveMessage.xsjs?component="+component,
							         	  
							         	url:"https://xs01a67a2589a.hana.ondemand.com/tmp/ong/pidemo/services/changeStatus.xsjs",
							          
							               dataType: "json",
							                data : { 
				           	         
				           	                             eqpID :      data.Name,
							                             status  :      "1"
							     
					             
				                           }
							    
							           });
        	 		           
        	 		           
        	 		           
        	 		           
        	 		           
        	 		           
        	 		           
        	 		           
        	 		           /////////////////////////////////////////////////
                	    	oModel.setProperty(path+"/status","Switch_on"); // ,data.status,true
                	    	oModel.setProperty(path+"/Power","10");
                	    	var tableList = sap.ui.getCore().byId('list');
        					var oTableBidingContext = tableList.getBindingContext();
        					var oModelData = oTableBidingContext.oModel.getObject(oTableBidingContext.sPath);
        					
        			
        					
        					oModelData.count.Switch_on = parseInt(oModelData.count.Switch_on, 10) + 1;
        					oModelData.count.Switch_off = parseInt(oModelData.count.Switch_off, 10) - 1;
        				// 	var oNewItemData = {
        				// 			id: data.id,
        				// 			Name: data.Name,
        				// 			Location: data.Location,
        				// 			Power: "30",
        				// 			status: "Switch_on",
  
        				// 		};
        					
        				// 	oModelData.items.push(oNewItemData);
        					
//        					 var path = oControlEvent.getSource().getParent().getBindingContext().sPath;
//        			         var obj = tableList.getModel().getProperty(path);
//        			         console.log(obj); // here is the object ot be deleted
//        			         tableList.getModel().getData().splice(parseInt(path.substring(1)), 1);
//        			         tableList.removeItem(oControlEvent.getParameter('listItem'));
        				
        					oTableBidingContext.oModel.refresh(true);
        					
                	    	
        	 		       }
          	         }
        	 }
         
         
         
         
          if(data.status === "Switch_on")
    	 {
    	     sap.ui.commons.MessageBox.confirm("Do you want to switch it off", fnCallbackConfirm1, "ALERT");
             function fnCallbackConfirm1(bResult1)  
      	         {
            	    if(bResult1==true)
    	 		       { 
    	 		          // alert("here");
    	 		           
    	 		            jQuery.ajax({
							         
							         	url:"https://xs01a67a2589a.hana.ondemand.com/tmp/ong/pidemo/services/changeStatus.xsjs",
							          
							               dataType: "json",
							                data : { 
				           	         
				           	                             eqpID :      data.Name,
							                             status  :      "0"
							     
					             
				                           }
							   
							           });
            	    	oModel.setProperty(path+"/status","Switch Off"); // ,data.status,true
                	    oModel.setProperty(path+"/Power","0");
            	    	
            	    	if(data.Name === "AC01")
            	    	{oModel.setProperty(path+"/Power","0");}
            	    	
            	    	var tableList = sap.ui.getCore().byId('list');
    					var oTableBidingContext = tableList.getBindingContext();
    					var oModelData = oTableBidingContext.oModel.getObject(oTableBidingContext.sPath);
    					
    				//	alert(oModelData.items.);
    					
    					
    					oModelData.count.Switch_on = parseInt(oModelData.count.Switch_on, 10) - 1;
    					oModelData.count.Switch_off = parseInt(oModelData.count.Switch_off, 10) + 1;
    				// 	var oNewItemData1 = {
    				// 			id: data.id,
    				// 			Name: data.Name,
    				// 			Location: data.Location,
    				// 			Power: "0",
    				// 			status: "Switch Off",

    				// 		};
    					
    				// 	oModelData.items.push(oNewItemData1);
    				//	oModelData.items.removeItem(data);
    					oTableBidingContext.oModel.refresh(true);
    					//tableList.refresh(true);
    					
            	    	
    	 		       }
      	         }
    	 }         
         
       
       },
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf smart_home.v2
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf smart_home.v2
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf smart_home.v2
*/
//	onExit: function() {
//
//	}

});